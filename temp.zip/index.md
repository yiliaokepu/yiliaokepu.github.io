---
# Feel free to add content and custom Front Matter to this file.
# To modify the layout, see https://jekyllrb.com/docs/themes/#overriding-theme-defaults

layout: home
---

<p align="center">
  <img src="/image/head.jpg" alt="drawing" width="200">
</p>


这是一个。。。。的网站

## 新冠病毒
 - 当前疫情
	- aaa, bbb, ccc
 - 防护措施 
	- ddd， eee，小红掌
 - 疫苗？？？
	- 还没

## 相关链接

 - [Division Particle & Astroparticle Physics, MPIK](https://www.mpi-hd.mpg.de/lin/group_members.en.html)
 - [MANITOP](https://www.mpi-hd.mpg.de/manitop/)
 - [scimeter.org](https://scimeter.org/clouds/author/?authors=0000-0003-3181-1386&author_disambiguate=Xun-Jie+Xu)
