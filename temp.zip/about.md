---
layout: page
title: Contact
permalink: /about/
---


## Preferred:

 - Email: <img src="/image/email.png" alt="email" width="200">

 - Instant Messaging :
	- Telegram (username:xunjiexu)
	- Google Hangouts (same as gmail)
	- Skype (same as gmail)
	- QQ (available upon request)

## Deprecated:

 - Wechat (available upon request. I usually do not check it regularly.)


