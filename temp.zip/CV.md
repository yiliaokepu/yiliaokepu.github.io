---
layout: page
title: CV
permalink: /CV/
---

## Education/Academic career
 - 2016/09 -- 2020/09:	Postdoctoral researcher at MPIK, Heidelberg, Germany.
 - 2011/09 -- 2016/06:	PhD, Tsinghua University, Beijing, China.
 - 2007/08 -- 2011/07:	Undergraduate, Tsinghua University, Beijing, China.

Full CV available upon request.
